<?php
    // session start
    if(!empty($_SESSION))
    {

     }
     else
     { 
        session_start(); 
    }
    require 'proses/panggil.php';
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title> Menambahkan barang </title>
		<!-- BOOTSTRAP CSS-->
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css"> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- DATATABLES CSS -->
        <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" /> -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" />
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" /> 
        
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- jQuery -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
        <!-- DATATABLES BS 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <!-- BOOTSTRAP 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

	</head>
    <body style="background:#586df5;">
            <?php 
                if(!empty($_SESSION['ADMIN']))
                {
                    include('view/navbar.php');
                }
            ?>    
	    <div class="container"> 
        <!-- <div> -->    
			<div class="row">
				<div class="col-lg-12">
                    <?php 
                        if(!empty($_SESSION['ADMIN']))
                        {
                    ?>
                    <br/>
                    <?php 
                        if($_SESSION['ADMIN']['IdAkses'] == 5
                           or $_SESSION['ADMIN']['IdAkses'] == 3)
                        {
                    ?>
                        <a href="tambah.php" class="btn btn-success btn-md"><span class="fa fa-plus"></span> Tambah Barang</a>
                    <?php
                        }
                    ?>
                    <br/><br/>

                    <!-- content body -->
                    <div class="container">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Data Barang</h4>
                            </div>
                            <div class="card-body">
                                <table class="table table-hover table-bordered" id="mytable" style="margin-top: 10px">
                                    <thead>
                                        <tr>
                                            <th width="50px">No</th>
                                            <th>Nama Barang</th>
                                            <th>Keterangan</th>
                                            <th>Satuan</th>
                                            <?php 
                                                if($_SESSION['ADMIN']['IdAkses'] == 5
                                                   or $_SESSION['ADMIN']['IdAkses'] == 3
                                                   or $_SESSION['ADMIN']['IdAkses'] == 4)
                                                {
                                            ?>
                                                <th style="text-align: center;">Aksi</th>
                                            <?php 
                                                } 
                                            ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $no=1;
                                        // ambil data berdasarkan user yang buat
                                        $hasil = $proses->tampil_data_barang('barang',$sesi['IdPengguna']);
                                        foreach($hasil as $isi){
                                    ?>
                                        <tr>
                                            <td><?php echo $no; ?></td>
                                            <td><?php echo $isi['NamaBarang']?></td>
                                            <td><?php echo $isi['Keterangan'];?></td>
                                            <td><?php echo $isi['satuan'];?></td>
                                            <?php 
                                                if($_SESSION['ADMIN']['IdAkses'] == 5)
                                                {
                                            ?>
                                                <td style="text-align: center;">                                          
                                                    <a href="edit.php?id=<?php echo $isi['IdBarang']; ?>" class="btn btn-success btn-md">
                                                        <span class="fa fa-edit"></span>
                                                    </a>
                                                    <a onclick="return confirm('Apakah yakin data akan di hapus?')" href="proses/crud.php?aksi=hapusBarang&IdBarang=<?php echo $isi['IdBarang'];?>" 
                                                    class="btn btn-danger btn-md">
                                                        <span class="fa fa-trash"></span>
                                                    </a>
                                                </td>
                                            <?php
                                                }
                                                elseif($_SESSION['ADMIN']['IdAkses'] == 3)
                                                {
                                            ?>
                                                <td style="text-align: center;">                                          
                                                    <a href="edit.php?id=<?php echo $isi['IdBarang']; ?>" class="btn btn-success btn-md">
                                                        <span class="fa fa-edit"></span>
                                                    </a>
                                                </td>                                            
                                            <?php 
                                                }
                                                elseif($_SESSION['ADMIN']['IdAkses'] == 4)
                                                { 
                                            ?>  
                                                <a onclick="return confirm('Apakah yakin data akan di hapus?')" href="proses/crud.php?aksi=hapusBarang&IdBarang=<?php echo $isi['IdBarang'];?>" 
                                                    class="btn btn-danger btn-md">
                                                    <span class="fa fa-trash"></span>
                                                </a>
                                            <?php
                                                } 

                                                else
                                                {}
                                            ?>
                                        </tr>
                                    <?php
                                        $no++;
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- content body -->
                    <?php 
                    }
                    else
                    {?>
                        <br/>
                        <div class="alert alert-info">
                            <h3> Maaf Anda Belum Dapat Akses CRUD, Silahkan Login Terlebih Dahulu !</h3>
                            <hr/>
                            <p><a href="login.php">Login Disini</a></p>
                        </div>
                    <?php 
                    }?>
			    </div>
			</div>
		</div>
        <script>
            $('#mytable').dataTable();
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

	</body>
</html>
