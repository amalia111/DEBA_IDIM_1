<?php
    // session start
    if(!empty($_SESSION))
	{ 

	}
	else
	{ 
		session_start(); 
	}
    //session
	if(!empty($_SESSION['ADMIN']))
	{ 

	}
	else
	{ 
		header('location:../login.php'); 
	}
    // panggil file
    require '../proses/panggil.php';
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Tambah Data Penjualan</title>
		<!-- BOOTSTRAP CSS-->
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css"> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- DATATABLES CSS -->
        <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" /> -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" />
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" /> 
        
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- jQuery -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
        <!-- DATATABLES BS 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <!-- BOOTSTRAP 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
	</head>
    <body style="background:#586df5;">
		<?php 
                if(!empty($_SESSION['ADMIN']))
                {
                    include('../view/navbar.php');
                }
        ?> 
		<div class="container">	
			<br/>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-lg-6">
					<br/>
					<div class="card">
						<div class="card-header">
						<h4 class="card-title">Tambah Penjualan</h4>
						</div>
						<div class="card-body">
						<!-- form berfungsi mengirimkan data input 
						dengan method post ke proses crud dengan paramater get aksi tambah -->
							<form action="../proses/crud.php?aksi=tambahPenjualan" method="POST">
								<div class="form-group">
									<label>Nama Barang </label>
									<select name="idbarang" id="idbarang" class="form-control">
                                    <?php
                                        $no=1;
                                        // ambil data berdasarkan user yang buat
                                        $hasil = $proses->tampil_data('Barang');

                                        foreach($hasil as $isi){
                                            $hasil2 = $proses->tampil_data_id('Pembelian','IdBarang',$isi['IdBarang']);
                                    ?>
                                        <option value="<?php echo $isi['IdBarang'];?>"><?php echo $isi['NamaBarang']; echo " - Rp";echo $hasil2['HargaBeli'];?></option>
                                        <?php } ?>
                                    </select>
								</div>
								<div class="form-group">
									<label>Jumlah Penjualan </label>
									<input type="number" value="" class="form-control" name="jumlah" required>
								</div>								
								<div class="form-group">
									<label>Harga Jual </label>
									<input type="number" value="" class="form-control" name="harga" required>
								</div>	
                                <div class="form-group">
									<label>Pelanggan </label>
									<select name="idpelanggan" id="idpelanggan" class="form-control">
                                    <?php
                                        $no=1;
                                        // ambil data berdasarkan user yang buat
                                        $hasil = $proses->tampil_data('pelanggan');
                                        foreach($hasil as $isi){
                                    ?>
                                        <option value="<?php echo $isi['IdPelanggan'];?>"><?php echo $isi['IdPelanggan']; echo " - "; echo $isi['JenisPelanggan'];?></option>
                                        <?php } ?>
                                    </select>
								</div>						
								<br/>
								<div class="row">
									<div class="col">
										<button class="btn btn-primary btn-md" name="create"><i class="fa fa-plus"> </i> Tambah Data</button>
									</div>
									<div class="col">
										<a href="index.php" class="btn btn-success btn-md" style="margin-right:1pc;"><span class="fa fa-home"></span> Kembali</a> 
									</div>									
								</div>
								
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
	</body>
</html>