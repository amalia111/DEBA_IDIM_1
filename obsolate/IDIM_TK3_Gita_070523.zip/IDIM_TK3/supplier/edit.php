<?php
    // session start
    if(!empty($_SESSION))
	{ }
	else
	{ session_start(); }
    //session
	if(!empty($_SESSION['ADMIN']))
	{ }
	else
	{ header('location:../login.php'); }
    // panggil file
    require '../proses/panggil.php';
    
    // tampilkan form edit
    $idGet = strip_tags($_GET['id']);
    $hasil = $proses->tampil_data_id('supplier','idSupplier',$idGet);

	// var_dump($idGet);
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Edit Supplier</title>
		<!-- BOOTSTRAP CSS-->
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css"> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- DATATABLES CSS -->
        <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" /> -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" />
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" /> 
        
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- jQuery -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
        <!-- DATATABLES BS 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <!-- BOOTSTRAP 4-->
        <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
	</head>
    <body style="background:#586df5;">
		<?php 
            if(!empty($_SESSION['ADMIN']))
            {
                include('view/navbar.php');
            }
        ?> 
		<div class="container">
			<br/>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-lg-6">
					<br/>
					<div class="card">
						<div class="card-header">
						<h4 class="card-title">Edit Supplier - <?php echo $hasil['NamaSupplier'];?></h4>
						</div>
						<div class="card-body">
						<!-- form berfungsi mengirimkan data input 
						dengan method post ke proses crud dengan paramater get aksi edit -->
							<form action="../proses/crud.php?aksi=editSupplier" method="POST">
								<div class="form-group">
									<label>Nama Supplier</label>
									<input type="text" value="<?php echo $hasil['NamaSupplier'];?>" class="form-control" name="namasupplier" required>
								</div>
								<div class="form-group">
									<label>Alamat </label>
									<input type="text" value="<?php echo $hasil['Alamat'];?>" class="form-control" name="alamat" required>
								</div>								
								<div class="form-group">
									<label>Kontak </label>
									<input type="text" value="<?php echo $hasil['Kontak'];?>" class="form-control" name="kontak" required>
								</div>
								<div class="form-group">
									<label>Channel Payment </label>
									<input type="text" value="<?php echo $hasil['ChannelPayment'];?>" class="form-control" name="channelpayment" required>
								</div>
								<div class="form-group">
									<input type="hidden" value="<?php echo $hasil['IdSupplier'];?>" class="form-control" name="IdSupplier" required>
								</div>
								<br/>
								<div class="row">
									<div class="col">
									<button class="btn btn-primary btn-md" name="create"><i class="fa fa-edit"> </i> Edit Data</button>
									</div>
									<div class="col">
										<a href="index.php" class="btn btn-success btn-md" style="margin-right:1pc;"><span class="fa fa-home"></span> Kembali</a> 
									</div>									
								</div>
								
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
		</div>
	</body>
</html>