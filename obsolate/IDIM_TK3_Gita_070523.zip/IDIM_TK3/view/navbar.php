                    <!-- NAVBAR -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="container-fluid">
                            <a class="navbar-brand" href="#">Navbar</a>
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                    <li class="nav-item">
                                        <?php
                                            // path link saat ini
                                            $actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                                                
                                            // kalau misalnya lagi di halaman laba rugi
                                            if($actual_link == 'http://localhost/testPHP/IDIM_TK3/view/labaRugi.php')
                                            {
                                                
                                        ?>
                                            <a class="nav-link" aria-current="page" href="../index.php">Barang</a>
                                        <?php
                                            }
                                            elseif($actual_link == 'http://localhost/testPHP/IDIM_TK3/index.php')
                                            {
                                        ?>
                                            <a class="nav-link" aria-current="page" href="index.php">Barang</a>
                                        <?php
                                            }
                                        ?>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="../view/labaRugi.php">Kalkulasi keuntungan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="../supplier/index.php">Supplier</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="../penjualan/index.php">Penjualan</a>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Dropdown
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <li><a class="dropdown-item" href="#">Action</a></li>
                                            <li><a class="dropdown-item" href="#">Another action</a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                                    </li>
                                </ul>
                                <div class="d-flex">
                                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                                        <li class="nav-item">
                                            <a class="nav-link" href="#"> Selamat Datang, <?php echo $sesi['NamaDepan'];?></a>
                                        </li> 
                                        <li class="nav-item dropdown">
                                            <?php
                                                // path link saat ini
                                                $actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                                                
                                                // kalau misalnya lagi di halaman laba rugi
                                                if($actual_link == 'http://localhost/testPHP/IDIM_TK3/view/labaRugi.php')
                                                {
                                            ?>
                                            <a href="../logout.php" class="nav-link"><span class="fa fa-sign-out"></span> Logout</a>
                                            <?php
                                                }
                                                elseif($actual_link == 'http://localhost/testPHP/IDIM_TK3/index.php')
                                                { 
                                            ?>
                                            <a href="logout.php" class="nav-link"><span class="fa fa-sign-out"></span> Logout</a>
                                            <?php
                                                }
                                            ?>
                                            
                                        </li>                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <!-- NAVBAR -->       