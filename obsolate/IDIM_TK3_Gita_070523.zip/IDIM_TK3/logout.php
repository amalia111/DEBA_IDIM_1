<?php
    session_start();
    session_destroy();
    // header("location:login.php?signout=sukses"); 
    header("location:index.php?signout=sukses"); 
?>